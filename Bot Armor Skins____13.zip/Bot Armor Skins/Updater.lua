if UpdateThisMod then
	UpdateThisMod:Add({
		mod_id = 'Bot Armor Skins',
		data = {
			modworkshop_id = 20918,
			dl_url = 'https://minhaskamal.github.io/DownGit/#home?url=https://github.com/DrNewbie/BotArmorSkins/tree/master/Bot Armor Skins',
			info_url = 'https://raw.githubusercontent.com/DrNewbie/BotArmorSkins/master/Bot%20Armor%20Skins/mod.txt'
		}
	})
end