if UpdateThisMod then
	UpdateThisMod:Add({
		mod_id = 'Bot Armor Skins',
		data = {
			modworkshop_id = 20918,
			dl_url = 'https://github.com/DrNewbie/BotArmorSkins/raw/master/Bot%20Armor%20Skins.zip',
			info_url = 'https://raw.githubusercontent.com/DrNewbie/BotArmorSkins/master/Bot%20Armor%20Skins/mod.txt'
		}
	})
end